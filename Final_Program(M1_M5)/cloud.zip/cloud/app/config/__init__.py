# Configuration settings for the Flask application
